RECEIVER: METHOD (Settings > 0. Method)
  Settings... (password) > "0. Method" > Method: Series / Wrap / BZ-HB / Normal (drop-down list).
  The selected method is shown in dark green bold, next to the "DB Search..." button (name only).
  The sender can send the data in any layout (one line or several lines, with or without a comma at the line end);
  the Receiver arranges it by the selected method. File name = data before the first comma. ONE file per message.
  A message is a list of comma separated fields:  carrier, n cavity values, n MLB SN, n Flex SN
  (your example: n = 6 -> 19 fields; the real DB data: n = 12 -> 37 fields). Empty fields are kept.
    Normal : as received (what the Receiver did before = old behaviour, default)
    Series : everything in ONE line
               JKABCD12345678,0,0,0,0,0,0,ABC...,ABC...,...,FLE...+1,FLE...+1,...
    Wrap   : 3 lines   line 1 = carrier + cavity values, line 2 = MLB SN, line 3 = Flex SN
               JKABCD12345678,0,0,0,0,0,0
               ABC001234567891234,...(6)
               FLE123456789123456+1,...(6)
    BZ-HB  : like Wrap, with 1,0 added after the carrier in line 1
               JKABCD12345678,1,0,0,0,0,0,0,0
               ABC001234567891234,...(6)
               FLE123456789123456+1,...(6)
  Line 1 = first 1+n fields, line 2 = next n fields, line 3 = the rest (n = (fields - 1) / 3). The last line never ends
  with a comma (empty fields at its end are dropped). In your text file the MLB line of the examples has 8 values but the
  syntax has 6; the rule above (3 equal parts) was used, it also fits the real 37-field data.
  The method is applied to the saved file AND to the DB record, so DB Search / download show the same arranged data.
  A connection test message (Communication test string) and empty messages are not arranged.
  Sender: no change.

M2M RECEIVER + SENDER — .NET FRAMEWORK 4.8

CURRENT SOURCE TARGET
- Both projects are classic MSBuild C# Windows Forms projects targeting .NET Framework 4.8.
- These project files do not use the .NET SDK-style project.assets.json / NuGet restore flow, so NETSDK1004 is avoided.
- The build script does not override the target framework to .NET 10.

BUILD IN VISUAL STUDIO
1. Install Visual Studio 2022 with the .NET desktop development workload and the .NET Framework 4.8 targeting pack.
2. Open M2M.sln.
3. Build > Rebuild Solution.
4. Executables are created at:
   M2M_Receiver\bin\Release\M2M_Receiver_1.exe
   M2M_Sender\bin\Release\M2M_Sender.exe

BUILD FROM COMMAND LINE
- Run Build_Offline.bat from a Visual Studio Developer Command Prompt, or a command prompt where MSBuild is available.
- This builds the solution for .NET Framework 4.8. No NuGet packages are required.

CURRENT REQUESTED RECEIVER CHANGES PRESERVED
- Receiver Settings > 6. Other > Receiver display name controls the prefix shown in the main status line, for example:
  M2M Receiver_1 Is Receiving Data From HB-1 Now... (1 sender(s))
- DB Search > Download file suggests a filename from the received data before the first comma or space.
- Working directory filename uses the same first field; Monitor folder filename uses:
  <data>_yyyyMMddHHmmss.txt (24-hour time).
- Existing Sender/Receiver features remain in the source, including manual Send, Auto-send, load file, TCP framing/checksum, ACK options, DB search, and settings.

.NET FRAMEWORK 4.8 COMPATIBILITY
- Network stream reads/writes use .NET Framework-compatible overloads.
- The projects use the C# compiler included with current Visual Studio 2022 (C# 10+ support is required for file-scoped namespaces and global using directives).

If Visual Studio reports a new compiler error, send the complete Error List and Output window text. The source has not been compiled in this environment because MSBuild/.NET Framework reference assemblies are unavailable here.
