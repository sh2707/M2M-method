using System.ComponentModel;
using M2M.Shared;

namespace M2M_Receiver;

/// <summary>
/// All Receiver settings. Shown in the Settings window and stored in M2M_Receiver_1.cfg.
/// The old keys keep their old names, so an existing .cfg file works as it is.
/// </summary>
public sealed class ReceiverSettings
{
    // ---------- Method ----------
    [Category("0. Method"), DisplayName("Method"), TypeConverter(typeof(ReceiveMethodConverter)),
     Description("How a received message is arranged before it is saved (file + DB). Normal = as received (the old behaviour). Series = everything in ONE line. Wrap = 3 lines (carrier + cavity data / MLB SN / Flex SN). BZ-HB = like Wrap, with 1,0 added after the carrier. The file name is always the data before the first comma.")]
    public string Method { get; set; } = ReceiveMethods.Normal;

    // ---------- Network ----------
    [Category("1. Network"), DisplayName("IP address"),
     Description("Address this PC listens on. 127.0.0.1 = this PC only. Use the PC's LAN IP, or 0.0.0.0 (all networks), so other PCs can connect.")]
    public string IpAddress { get; set; } = "127.0.0.1";

    [Category("1. Network"), DisplayName("Port"), Description("TCP port to listen on (1-65535).")]
    public int Port { get; set; } = 1900;

    [Category("1. Network"), DisplayName("Max clients"),
     Description("How many senders may be connected at the same time. 0 = no limit.")]
    public int MaxClients { get; set; } = 0;

    // ---------- Files ----------
    [Category("2. Files"), DisplayName("Working directory"), Description("Every received message is saved here as a file.")]
    public string WorkingDirectory { get; set; } = @"C:\SH\M2M_ReceivedFolder";

    [Category("2. Files"), DisplayName("Working directory monitor"), Description("A second copy of every file is saved here. Empty = no copy.")]
    public string WorkingDirectoryMonitor { get; set; } = @"C:\SH\M2M_SH_Test_ReceivedFolder_Monitor";

    [Category("2. Files"), DisplayName("File format"), Description("Extension of the saved files, for example .txt")]
    public string FileFormat { get; set; } = ".txt";

    // ---------- Timing ----------
    [Category("3. Timing"), DisplayName("Timer interval (ms)"), Description("How often the app checks for finished messages.")]
    public int TimerInterval { get; set; } = 50;

    [Category("3. Timing"), DisplayName("Message gap (ms)"),
     Description("Framing = None only: data that arrives together, with no pause longer than this, is ONE message.")]
    public int MessageGapMs { get; set; } = 200;

    // ---------- Message format ----------
    [Category("4. Message format"), DisplayName("Framing"),
     Description("None = old behaviour (a burst of data is one message). Line = ends with a new line. StxEtx = 0x02 ... 0x03. LengthPrefix = 2-byte length first. Fixed = always the same length. The Sender must use the same setting.")]
    public FramingMode Framing { get; set; } = FramingMode.None;

    [Category("4. Message format"), DisplayName("Checksum"),
     Description("Only for StxEtx and LengthPrefix. Added at the end of the message as ASCII hex text (XOR / SUM8 = 2 characters, CRC16 = 4). A message with a wrong checksum is rejected.")]
    public ChecksumMode Checksum { get; set; } = ChecksumMode.None;

    [Category("4. Message format"), DisplayName("Fixed length"), Description("Message length in bytes when Framing = Fixed.")]
    public int FixedLength { get; set; } = 16;

    [Category("4. Message format"), DisplayName("Communication test string"),
     Description("A message that is exactly this text is only a connection test. It is answered but not saved or logged. Case, spaces, _ and - are ignored (M2M TestFile = M2M_TestFile).")]
    public string CommunicationTestString { get; set; } = "M2M_TestFile";

    // ---------- ACK / reply ----------
    [Category("5. ACK / auto-reply"), DisplayName("Auto-ACK"),
     Description("Answer every saved message with the ACK text. Answer a bad / failed message with the NAK text.")]
    public bool AutoAck { get; set; } = false;

    [Category("5. ACK / auto-reply"), DisplayName("ACK text")]
    public string AckText { get; set; } = "ACK";

    [Category("5. ACK / auto-reply"), DisplayName("NAK text")]
    public string NakText { get; set; } = "NAK";

    [Category("5. ACK / auto-reply"), DisplayName("Auto-reply"),
     Description("Also send the reply text below when a received message matches the rule.")]
    public bool AutoReplyEnabled { get; set; } = false;

    [Category("5. ACK / auto-reply"), DisplayName("Reply when message contains"),
     Description("Text to look for (not case sensitive). Empty = reply to every message.")]
    public string AutoReplyMatch { get; set; } = "";

    [Category("5. ACK / auto-reply"), DisplayName("Reply text")]
    public string AutoReplyText { get; set; } = "";

    // ---------- Machines / display ----------
    [Category("6. Other"), DisplayName("Receiver display name"), Description("Editable name shown at the start of the main status line, for example M2M Receiver_1.")]
    public string ReceiverDisplayName { get; set; } = "M2M Receiver_1";

    [Category("6. Other"), DisplayName("Machine A"), Description("Shown in the status line.")]
    public string MachineA { get; set; } = "Asymtek";

    [Category("6. Other"), DisplayName("Window name (optional)"),
     Description("Shown after the title, for example Line1  ->  \"M2M Receiver - Line1\". Use it to tell apart several Receivers on one PC. Empty = the title is only \"M2M Receiver\".")]
    public string WindowName { get; set; } = "";

    [Category("6. Other"), DisplayName("Machine B")]
    public string MachineB { get; set; } = "UAT-01";

    [Category("6. Other"), DisplayName("Max log lines"), Description("Older lines are removed from the screen after this many.")]
    public int MaxLogLines { get; set; } = 2000;

    // ---------- Protection / monitoring (new) ----------
    [Category("7. Protection / monitoring"), DisplayName("Allowed sender IPs"),
     Description("Only these sender IP addresses may connect, separated by comma, for example 192.168.1.20,192.168.1.21. Empty = every sender is allowed (old behaviour).")]
    public string AllowedSenderIps { get; set; } = "";

    [Category("7. Protection / monitoring"), DisplayName("No-data alarm (minutes)"),
     Description("If nothing is received for this many minutes, a red alarm is shown (and logged, with a beep). 0 = off.")]
    public int NoDataAlarmMinutes { get; set; } = 0;

    [Category("7. Protection / monitoring"), DisplayName("Duplicate filter (seconds)"),
     Description("The same message received again within this many seconds is not saved a second time (the sender still gets its ACK). 0 = off (old behaviour: everything is saved).")]
    public int DuplicateWindowSec { get; set; } = 0;

    [Category("7. Protection / monitoring"), DisplayName("Log empty messages to DB"),
     Description("The old Receiver wrote empty messages into the DB file (timestamp only). True = same as the old one. No file is created for an empty message.")]
    public bool LogEmptyToDb { get; set; } = true;

    // ---------- load / save ----------
    public ReceiverSettings Clone() => (ReceiverSettings)MemberwiseClone();

    public static ReceiverSettings LoadFrom(IniConfig c)
    {
        var d = new ReceiverSettings();
        var s = new ReceiverSettings
        {
            IpAddress = c.Get("M2M_Receiver_IP_Address", d.IpAddress),
            Port = c.GetInt("M2M_Receiver_Port", d.Port),
            MaxClients = c.GetInt("M2M_Receiver_MaxClients", d.MaxClients),
            WorkingDirectory = c.Get("M2M_Receiver_WorkingDirectory", d.WorkingDirectory),
            WorkingDirectoryMonitor = c.Get("M2M_Receiver_WorkingDirectoryMonitor", d.WorkingDirectoryMonitor),
            FileFormat = c.Get("M2M_Receiver_FileFormat", d.FileFormat),
            TimerInterval = c.GetInt("M2M_Receiver_TimerInterval", d.TimerInterval),
            MessageGapMs = c.GetInt("M2M_Receiver_MessageGapMs", d.MessageGapMs),
            Framing = ParseEnum(c.Get("M2M_Framing"), d.Framing),
            Checksum = ParseEnum(c.Get("M2M_Checksum"), d.Checksum),
            FixedLength = c.GetInt("M2M_FixedLength", d.FixedLength),
            CommunicationTestString = c.Get("M2M_CommunicationTestString", d.CommunicationTestString),
            AutoAck = c.GetBool("M2M_AutoAck", d.AutoAck),
            AckText = c.Get("M2M_AckText", d.AckText),
            NakText = c.Get("M2M_NakText", d.NakText),
            AutoReplyEnabled = c.GetBool("M2M_AutoReply", d.AutoReplyEnabled),
            AutoReplyMatch = c.Get("M2M_AutoReplyMatch", d.AutoReplyMatch),
            AutoReplyText = c.Get("M2M_AutoReplyText", d.AutoReplyText),
            MachineA = c.Get("Machine_A", d.MachineA),
            ReceiverDisplayName = c.Get("M2M_Receiver_DisplayName", d.ReceiverDisplayName),
            MachineB = c.Get("Machine_B", d.MachineB),
            WindowName = c.Get("M2M_Receiver_WindowName", d.WindowName),
            MaxLogLines = c.GetInt("M2M_Receiver_MaxLogLines", d.MaxLogLines),
            AllowedSenderIps = c.Get("M2M_Receiver_AllowedIPs", d.AllowedSenderIps),
            NoDataAlarmMinutes = c.GetInt("M2M_Receiver_NoDataAlarmMin", d.NoDataAlarmMinutes),
            DuplicateWindowSec = c.GetInt("M2M_Receiver_DuplicateSec", d.DuplicateWindowSec),
            LogEmptyToDb = c.GetBool("M2M_Receiver_LogEmptyToDb", d.LogEmptyToDb),
            Method = c.Get("M2M_Receiver_Method", d.Method)
        };
        s.Normalize();
        return s;
    }

    public void SaveTo(IniConfig c)
    {
        if (!c.Has("Software_VersionInformation")) c.Set("Software_VersionInformation", "M2M Receiver_1 2026-10-27");

        c.Set("M2M_Receiver_IP_Address", IpAddress);
        c.Set("M2M_Receiver_Port", Port);
        c.Set("M2M_Receiver_MaxClients", MaxClients);
        c.Set("M2M_Receiver_WorkingDirectory", WorkingDirectory);
        c.Set("M2M_Receiver_WorkingDirectoryMonitor", WorkingDirectoryMonitor);
        c.Set("M2M_Receiver_FileFormat", FileFormat);
        c.Set("M2M_Receiver_TimerInterval", TimerInterval);
        c.Set("M2M_Receiver_MessageGapMs", MessageGapMs);
        c.Set("M2M_Framing", Framing.ToString());
        c.Set("M2M_Checksum", Checksum.ToString());
        c.Set("M2M_FixedLength", FixedLength);
        c.Set("M2M_CommunicationTestString", CommunicationTestString);
        c.Set("M2M_AutoAck", AutoAck);
        c.Set("M2M_AckText", AckText);
        c.Set("M2M_NakText", NakText);
        c.Set("M2M_AutoReply", AutoReplyEnabled);
        c.Set("M2M_AutoReplyMatch", AutoReplyMatch);
        c.Set("M2M_AutoReplyText", AutoReplyText);
        c.Set("Machine_A", MachineA);
        c.Set("M2M_Receiver_DisplayName", ReceiverDisplayName);
        c.Set("Machine_B", MachineB);
        c.Set("M2M_Receiver_WindowName", WindowName);
        c.Set("M2M_Receiver_MaxLogLines", MaxLogLines);
        c.Set("M2M_Receiver_AllowedIPs", AllowedSenderIps);
        c.Set("M2M_Receiver_NoDataAlarmMin", NoDataAlarmMinutes);
        c.Set("M2M_Receiver_DuplicateSec", DuplicateWindowSec);
        c.Set("M2M_Receiver_LogEmptyToDb", LogEmptyToDb);
        c.Set("M2M_Receiver_Method", Method);
        c.Save();
    }

    /// <summary>Puts every value into a safe range.</summary>
    public void Normalize()
    {
        Port = Math.Min(65535, Math.Max(1, Port));
        MaxClients = Math.Max(0, MaxClients);
        TimerInterval = Math.Min(5000, Math.Max(10, TimerInterval));
        MessageGapMs = Math.Min(60000, Math.Max(10, MessageGapMs));
        FixedLength = Math.Min(65535, Math.Max(1, FixedLength));
        MaxLogLines = Math.Min(100000, Math.Max(100, MaxLogLines));
        NoDataAlarmMinutes = Math.Min(10080, Math.Max(0, NoDataAlarmMinutes));
        DuplicateWindowSec = Math.Min(86400, Math.Max(0, DuplicateWindowSec));
        AllowedSenderIps = (AllowedSenderIps ?? "").Trim();
        Method = ReceiveMethods.Fix(Method);
        WindowName = (WindowName ?? "").Trim();
        ReceiverDisplayName = (ReceiverDisplayName ?? "").Trim();
        if (ReceiverDisplayName.Length == 0) ReceiverDisplayName = "M2M Receiver_1";
        IpAddress = (IpAddress ?? "").Trim();
        FileFormat = Util.NormalizeExt(FileFormat);
        AckText ??= "";
        NakText ??= "";
        AutoReplyMatch ??= "";
        AutoReplyText ??= "";
        CommunicationTestString ??= "";
        WorkingDirectory ??= "";
        WorkingDirectoryMonitor ??= "";
    }

    private static T ParseEnum<T>(string text, T def) where T : struct, Enum
        => Enum.TryParse<T>(text, true, out var v) && Enum.IsDefined(typeof(T), v) ? v : def;
}

/// <summary>The drop-down list for the Method setting (Series, Wrap, BZ-HB, Normal).</summary>
public sealed class ReceiveMethodConverter : StringConverter
{
    public override bool GetStandardValuesSupported(ITypeDescriptorContext context) { return true; }

    public override bool GetStandardValuesExclusive(ITypeDescriptorContext context) { return true; }

    public override StandardValuesCollection GetStandardValues(ITypeDescriptorContext context)
    {
        return new StandardValuesCollection(ReceiveMethods.All);
    }
}

/// <summary>
/// Arranges a received message by the selected Method.
/// The message is a list of comma separated fields:  carrier, n cavity values, n MLB SN, n Flex SN
/// (for example n = 6 -> 19 fields, in the real data n = 12 -> 37 fields). Empty fields are kept.
///   Normal : nothing changes (old behaviour)
///   Series : all fields in ONE line
///   Wrap   : line 1 = carrier + cavity values, line 2 = MLB SN, line 3 = Flex SN
///   BZ-HB  : like Wrap, but "1,0" is added after the carrier in line 1
/// Line 1 gets the first 1+n fields, line 2 the next n, line 3 the rest (n = (fields - 1) / 3).
/// Empty fields keep their commas; only an extra comma beyond the expected field count is not added to the last line.
/// </summary>
public static class ReceiveMethods
{
    public const string Series = "Series";
    public const string Wrap = "Wrap";
    public const string BzHb = "BZ-HB";
    public const string Normal = "Normal";

    public static readonly string[] All = { Series, Wrap, BzHb, Normal };

    /// <summary>Returns a valid method name (anything unknown = Normal).</summary>
    public static string Fix(string method)
    {
        string m = (method ?? "").Trim();
        foreach (string name in All)
            if (string.Equals(name, m, StringComparison.OrdinalIgnoreCase)) return name;
        if (string.Equals(m.Replace("-", "").Replace(" ", ""), "BZHB", StringComparison.OrdinalIgnoreCase)) return BzHb;
        return Normal;
    }

    public static string Apply(string method, string text)
    {
        method = Fix(method);
        if (method == Normal || string.IsNullOrEmpty(text)) return text;

        List<string> fields = SplitFields(text);

        if (method == Series) return string.Join(",", fields);
        return ThreeLines(fields, method == BzHb);
    }

    // The message may come in one line or in several lines: lines are joined with a comma (no double comma).
    private static List<string> SplitFields(string text)
    {
        var sb = new StringBuilder();
        foreach (string raw in text.Replace("\r\n", "\n").Replace('\r', '\n').Split('\n'))
        {
            string line = raw.Trim();
            if (line.Length == 0) continue;
            if (sb.Length > 0 && sb[sb.Length - 1] != ',') sb.Append(',');
            sb.Append(line);
        }

        var fields = new List<string>();
        foreach (string f in sb.ToString().Split(','))
            fields.Add(f.Trim());
        return fields;
    }

    private static string ThreeLines(List<string> f, bool extra)
    {
        int n = f.Count > 1 ? (f.Count - 1) / 3 : 0;

        var line1 = new List<string>();
        line1.Add(f.Count > 0 ? f[0] : "");
        if (extra)
        {
            line1.Add("1");
            line1.Add("0");
        }
        for (int i = 1; i <= n && i < f.Count; i++) line1.Add(f[i]);

        var line2 = new List<string>();
        for (int i = 1 + n; i < 1 + 2 * n && i < f.Count; i++) line2.Add(f[i]);

        var line3 = new List<string>();
        for (int i = 1 + 2 * n; i < f.Count; i++) line3.Add(f[i]);

        // Empty fields are KEPT (same number of commas as the syntax). Only the extra empty fields beyond the
        // expected 1 + 3n (for example a comma at the very end of the sender's text) are dropped, so the last
        // line does not get a stray comma.
        while (line3.Count > n && line3[line3.Count - 1].Length == 0) line3.RemoveAt(line3.Count - 1);

        return string.Join(",", line1) + "\r\n" + string.Join(",", line2) + "\r\n" + string.Join(",", line3);
    }
}
