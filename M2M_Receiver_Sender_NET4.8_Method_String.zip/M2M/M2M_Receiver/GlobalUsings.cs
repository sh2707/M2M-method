// Common namespaces formerly provided by ImplicitUsings in the SDK-style projects.
global using System;
global using System.Collections.Generic;
global using System.ComponentModel;
global using System.Drawing;
global using System.IO;
global using System.Linq;
global using System.Net;
global using System.Net.Sockets;
global using System.Text;
global using System.Threading;
global using System.Threading.Tasks;
global using System.Windows.Forms;
