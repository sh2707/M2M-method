namespace M2M_Receiver;

static class Program
{
    [STAThread]
    static void Main()
    {
        // Only one copy of the app may run FROM THE SAME FOLDER (same .cfg / same port).
        // A copy placed in another folder can run at the same time (own .cfg, own DB, own port).
        byte[] folderHash;
        using (var sha = System.Security.Cryptography.SHA256.Create())
            folderHash = sha.ComputeHash(System.Text.Encoding.UTF8.GetBytes(AppDomain.CurrentDomain.BaseDirectory.ToLowerInvariant()));
        string folderKey = BitConverter.ToString(folderHash).Replace("-", "").Substring(0, 16);
        using var mutex = new Mutex(true, "M2M_Receiver_1_SingleInstance_" + folderKey, out bool isFirst);
        if (!isFirst)
        {
            MessageBox.Show("You can't open this APP because it has already been open !!!\r\n\r\n"
                + "(To run more Receivers on this PC, copy the exe into another folder and set a different Port there.)", "Tip",
                MessageBoxButtons.OK, MessageBoxIcon.Information);
            return;
        }

        Application.EnableVisualStyles();
        Application.SetCompatibleTextRenderingDefault(false);
        Application.Run(new MainForm());
    }
}
