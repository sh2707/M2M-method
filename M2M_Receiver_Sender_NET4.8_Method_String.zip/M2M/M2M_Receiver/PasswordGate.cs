using System.Security.Cryptography;
using System.Text;

namespace M2M.Shared;

/// <summary>
/// Close / settings password. Reads the same key as the old apps
/// (Software_Close_EncodedPassword). An old plain value still works;
/// when the password is changed it is stored as a SHA-256 hash.
/// </summary>
public static class PasswordGate
{
    public const string Key = "Software_Close_EncodedPassword";
    public const string DefaultPassword = "SH";   // same default as the old apps - change it!

    public static bool Verify(string stored, string typed)
    {
        if (stored.StartsWith("sha256:", StringComparison.OrdinalIgnoreCase))
            return Hash(typed).Equals(stored.Substring(7), StringComparison.OrdinalIgnoreCase);
        return stored == typed;   // legacy plain value
    }

    public static string MakeStored(string password) => "sha256:" + Hash(password);

    private static string Hash(string s)
    {
        using (var sha = SHA256.Create())
        {
            byte[] bytes = sha.ComputeHash(Encoding.UTF8.GetBytes(s));
            return BitConverter.ToString(bytes).Replace("-", "");
        }
    }

    /// <summary>Asks for the password. True only if it is correct.</summary>
    // Migrate the previously used password to the requested password once.
    // This handles both legacy plain-text values and SHA-256 stored values.
    private static string GetCurrentStoredPassword(IniConfig cfg)
    {
        string stored = cfg.Get(Key, DefaultPassword);
        if (Verify(stored, "xyz678"))
        {
            stored = DefaultPassword;
            cfg.Set(Key, MakeStored(DefaultPassword));
            cfg.Save();
        }
        return stored;
    }

    public static bool Ask(IWin32Window? owner, IniConfig cfg, string purpose)
    {
        string stored = GetCurrentStoredPassword(cfg);
        string? typed = Prompt(owner, "Password required", $"Enter password ({purpose}):");
        if (typed == null) return false;
        if (Verify(stored, typed)) return true;
        MessageBox.Show(owner, "Wrong password.", "Tip", MessageBoxButtons.OK, MessageBoxIcon.Warning);
        return false;
    }

    public static void Change(IWin32Window? owner, IniConfig cfg)
    {
        string stored = GetCurrentStoredPassword(cfg);

        string? old = Prompt(owner, "Change password", "Old password:");
        if (old == null) return;
        if (!Verify(stored, old))
        {
            MessageBox.Show(owner, "Old password is wrong.", "Tip", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            return;
        }

        string? n1 = Prompt(owner, "Change password", "New password:");
        if (string.IsNullOrEmpty(n1)) return;
        string? n2 = Prompt(owner, "Change password", "Confirm new password:");
        if (n2 == null) return;
        if (n1 != n2)
        {
            MessageBox.Show(owner, "The two passwords do not match.", "Tip", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            return;
        }

        cfg.Set(Key, MakeStored(n1));
        cfg.Save();
        MessageBox.Show(owner, "Password changed.", "Tip", MessageBoxButtons.OK, MessageBoxIcon.Information);
    }

    private static string? Prompt(IWin32Window? owner, string title, string label)
    {
        using var f = new Form
        {
            Text = title,
            FormBorderStyle = FormBorderStyle.FixedDialog,
            StartPosition = FormStartPosition.CenterParent,
            MinimizeBox = false,
            MaximizeBox = false,
            ShowInTaskbar = false,
            ClientSize = new Size(330, 110)
        };
        var lbl = new Label { Text = label, Left = 12, Top = 12, Width = 306 };
        var tb = new TextBox { Left = 12, Top = 36, Width = 306, UseSystemPasswordChar = true };
        var ok = new Button { Text = "OK", Left = 162, Top = 72, Width = 75, DialogResult = DialogResult.OK };
        var cancel = new Button { Text = "Cancel", Left = 243, Top = 72, Width = 75, DialogResult = DialogResult.Cancel };
        f.Controls.Add(lbl);
        f.Controls.Add(tb);
        f.Controls.Add(ok);
        f.Controls.Add(cancel);
        f.AcceptButton = ok;
        f.CancelButton = cancel;
        return f.ShowDialog(owner) == DialogResult.OK ? tb.Text : null;
    }
}
