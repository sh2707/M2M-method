// Compatibility shim for C# init-only properties when targeting .NET Framework 4.8.
namespace System.Runtime.CompilerServices
{
    internal static class IsExternalInit { }
}
