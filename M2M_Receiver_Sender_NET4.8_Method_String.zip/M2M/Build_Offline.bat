@echo off
setlocal
cd /d "%~dp0"
title M2M - .NET Framework 4.8 build

echo Building M2M Receiver and Sender for .NET Framework 4.8...
echo.

where msbuild >nul 2>&1
if not errorlevel 1 (
  msbuild M2M.sln /t:Rebuild /p:Configuration=Release /p:Platform="Any CPU"
  if errorlevel 1 goto failed
  goto success
)

where dotnet >nul 2>&1
if not errorlevel 1 (
  dotnet msbuild M2M.sln /t:Rebuild /p:Configuration=Release /p:Platform="Any CPU"
  if errorlevel 1 goto failed
  goto success
)

echo ERROR: MSBuild was not found. Install Visual Studio Build Tools with the .NET desktop build tools
 echo and the .NET Framework 4.8 targeting pack, then run this file again.
pause
exit /b 1

:success
echo.
echo BUILD SUCCEEDED.
echo Receiver: M2M_Receiver\bin\Release\M2M_Receiver_1.exe
echo Sender:   M2M_Sender\bin\Release\M2M_Sender.exe
echo Target framework: .NET Framework 4.8 (not .NET 10)
echo.
pause
exit /b 0

:failed
echo.
echo BUILD FAILED. Copy the complete error text above.
echo.
pause
exit /b 1
