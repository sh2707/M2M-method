using System.Net.Sockets;
using System.Text;
using M2M.Shared;

namespace M2M_Sender;

public class MainForm : Form
{
    private const string AppName = "M2M Sender";
    private static readonly string CfgPath = Path.Combine(Application.StartupPath, "M2M_Sender.cfg");

    private readonly IniConfig cfg;
    private SenderSettings settings;

    // ---- UI ----
    private readonly Label lblStatus = new()
    {
        Dock = DockStyle.Top,
        Height = 40,
        TextAlign = ContentAlignment.MiddleCenter,
        Font = new Font("Microsoft Sans Serif", 12, FontStyle.Bold),
        ForeColor = Color.Red,
        Text = "Starting ..."
    };
    private readonly Panel panelSending = new() { Dock = DockStyle.Top, Height = 110, Padding = new Padding(8, 4, 8, 4) };
    private readonly Label lblSending = new() { Text = "SENDING:", AutoSize = true, Dock = DockStyle.Top, Font = new Font("Microsoft Sans Serif", 9, FontStyle.Bold) };
    private readonly TextBox txtSendingContent = new() { Dock = DockStyle.Fill, Multiline = true, ReadOnly = true, ScrollBars = ScrollBars.Vertical, Font = new Font("Consolas", 10) };
    private readonly Panel panelManual = new() { Dock = DockStyle.Top, Height = 38, Padding = new Padding(8, 5, 8, 4) };
    private readonly TextBox txtManual = new() { Dock = DockStyle.Fill };
    private readonly Button btnManual = new() { Text = "Send", Dock = DockStyle.Right, Width = 80 };
    private readonly Button btnLoadFile = new() { Text = "Load File...", Dock = DockStyle.Right, Width = 100 };
    private readonly CheckBox chkAutoSend = new() { Text = "Auto-send", Dock = DockStyle.Right, AutoSize = true, Padding = new Padding(8, 0, 0, 0) };
    private readonly LogBox txtLog = new() { Dock = DockStyle.Fill };
    private readonly FlowLayoutPanel bottom = new() { Dock = DockStyle.Fill, Padding = new Padding(6) };
    private readonly Panel bottomBar = new() { Dock = DockStyle.Bottom, Height = 44 };
    private readonly Label lblDev = new()
    {
        Text = "Developed by SH",
        Dock = DockStyle.Right,
        Width = 140,
        TextAlign = ContentAlignment.MiddleRight,
        Padding = new Padding(0, 0, 10, 0),
        Font = new Font("Microsoft Sans Serif", 9.5f, FontStyle.Bold),
        ForeColor = Color.Black
    };
    private readonly Button btnConnect = new() { Text = "Disconnect", Width = 100 };
    private readonly Button btnSettings = new() { Text = "Settings...", Width = 100 };
    private readonly Button btnClearLog = new() { Text = "Clear log", Width = 90 };

    // ---- connection state ----
    private TcpClient? client;
    private NetworkStream? stream;
    private MessageAssembler assembler = new();
    private CancellationTokenSource? cts;
    private bool wantConnected = true;
    private TaskCompletionSource<bool>? ackWaiter;     // set while we wait for ACK / NAK
    private readonly SemaphoreSlim sendGate = new(1, 1);   // one message at a time

    // ---- timers ----
    private readonly System.Windows.Forms.Timer cycleTimer = new();      // send-folder cycle
    private readonly System.Windows.Forms.Timer replyTimer = new() { Interval = 20 };   // closes reply bursts (Framing = None)
    private readonly System.Windows.Forms.Timer autoSendTimer = new();
    private bool cycleBusy;
    private bool autoBusy;

    public MainForm()
    {
        bool firstRun = !File.Exists(CfgPath);
        cfg = new IniConfig(CfgPath);
        settings = SenderSettings.LoadFrom(cfg);
        if (firstRun) settings.SaveTo(cfg);

        Text = "M2M Sender";
        try { Icon = Icon.ExtractAssociatedIcon(Application.ExecutablePath); } catch { /* icon is optional */ }
        ClientSize = new Size(760, 540);
        MinimumSize = new Size(640, 420);
        StartPosition = FormStartPosition.CenterScreen;

        panelSending.Controls.Add(txtSendingContent);
        panelSending.Controls.Add(lblSending);

        panelManual.Controls.Add(txtManual);
        panelManual.Controls.Add(btnLoadFile);
        panelManual.Controls.Add(chkAutoSend);
        panelManual.Controls.Add(btnManual);

        bottom.Controls.Add(btnConnect);
        bottom.Controls.Add(btnSettings);
        bottom.Controls.Add(btnClearLog);

        Controls.Add(txtLog);
        Controls.Add(panelManual);
        Controls.Add(panelSending);
        Controls.Add(lblStatus);
        bottomBar.Controls.Add(bottom);   // dock order: the control added last is laid out first
        bottomBar.Controls.Add(lblDev);
        Controls.Add(bottomBar);

        btnConnect.Click += (_, _) => ToggleConnection();
        btnSettings.Click += (_, _) => OpenSettings();
        btnClearLog.Click += (_, _) => txtLog.Clear();
        btnManual.Click += async (_, _) => await SendManualAsync();
        btnLoadFile.Click += async (_, _) => await LoadFileAndSendAsync();
        txtManual.KeyDown += async (_, e) =>
        {
            if (e.KeyCode == Keys.Enter)
            {
                e.SuppressKeyPress = true;
                await SendManualAsync();
            }
        };
        chkAutoSend.CheckedChanged += (_, _) => AutoSendChanged();

        cycleTimer.Tick += async (_, _) => await CycleAsync();
        replyTimer.Tick += (_, _) => PollReplyGap();
        autoSendTimer.Tick += async (_, _) => await AutoSendTickAsync();

        Shown += (_, _) => ApplySettings();
    }

    // ================= settings =================

    private void OpenSettings()
    {
        if (!PasswordGate.Ask(this, cfg, "Settings")) return;

        var copy = settings.Clone();
        using var dlg = new SettingsForm(copy, AppName + " - Settings", cfg);
        if (dlg.ShowDialog(this) != DialogResult.OK) return;

        copy.Normalize();
        try
        {
            copy.SaveTo(cfg);
        }
        catch (Exception ex)
        {
            MessageBox.Show(this, "Cannot save the .cfg file: " + ex.Message, "Tip", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            return;
        }
        settings = copy;
        Log("Settings saved - connecting again");
        ApplySettings();
    }

    private void ApplySettings()
    {
        StopConnection();
        txtLog.MaxLines = settings.MaxLogLines;
        cycleTimer.Interval = Math.Max(50, settings.TimerInterval);
        cycleTimer.Start();
        replyTimer.Start();
        if (chkAutoSend.Checked) autoSendTimer.Interval = settings.AutoSendIntervalMs;
        if (wantConnected) StartConnection();
        else SetStatus("Disconnected (press Connect)", Color.Red);
    }

    // ================= connection =================

    private void ToggleConnection()
    {
        if (wantConnected)
        {
            wantConnected = false;
            StopConnection();
            btnConnect.Text = "Connect";
            SetStatus("Disconnected (press Connect)", Color.Red);
        }
        else
        {
            wantConnected = true;
            btnConnect.Text = "Disconnect";
            StartConnection();
        }
    }

    private void StartConnection()
    {
        cts = new CancellationTokenSource();
        _ = ConnectionLoopAsync(cts.Token);
    }

    private void StopConnection()
    {
        try { cts?.Cancel(); } catch { }
        DropConnection();
    }

    private void DropConnection()
    {
        var s = stream;
        var c = client;
        stream = null;
        client = null;
        ackWaiter?.TrySetResult(false);
        try { s?.Close(); } catch { }
        try { c?.Close(); } catch { }
    }

    private async Task ConnectionLoopAsync(CancellationToken token)
    {
        string ip = settings.AoiIpAddress;
        int port = settings.AoiPort;

        while (!token.IsCancellationRequested)
        {
            TcpClient? tc = null;
            try
            {
                SetStatus($"Connecting to {ip}:{port} ...", Color.Red);
                tc = new TcpClient();

                using (var connectCts = CancellationTokenSource.CreateLinkedTokenSource(token))
                {
                    connectCts.CancelAfter(TimeSpan.FromSeconds(5));
                    try
                    {
                        await tc.ConnectAsync(ip, port).ConfigureAwait(false);
                        if (connectCts.IsCancellationRequested) throw new OperationCanceledException();
                    }
                    catch (OperationCanceledException) when (!token.IsCancellationRequested)
                    {
                        throw new TimeoutException("connection timed out (5 s)");
                    }
                }

                client = tc;
                stream = tc.GetStream();
                assembler = new MessageAssembler { Mode = settings.Framing, FixedLength = settings.FixedLength };
                Log($"Connected to {ip}:{port}");
                SetStatus($"Connected to {ip}:{port}", Color.DarkGreen);

                await ReceiveLoopAsync(stream, assembler, token);
            }
            catch (OperationCanceledException)
            {
                break;
            }
            catch (Exception ex)
            {
                if (token.IsCancellationRequested) break;
                Log($"Connection failed: {ex.Message}");
            }
            finally
            {
                // only drop the connection if it is still OURS (Settings may already have started a new one)
                if (ReferenceEquals(client, tc)) DropConnection();
                try { tc?.Close(); } catch { }
            }

            if (token.IsCancellationRequested) break;
            if (!settings.AutoReconnect)
            {
                wantConnected = false;
                btnConnect.Text = "Connect";
                SetStatus("Disconnected (press Connect)", Color.Red);
                break;
            }

            SetStatus($"Disconnected - reconnecting in {settings.ReconnectDelayMs / 1000.0:0.#} s", Color.Red);
            try { await Task.Delay(settings.ReconnectDelayMs, token); }
            catch (OperationCanceledException) { break; }
        }
    }

    private async Task ReceiveLoopAsync(NetworkStream s, MessageAssembler asm, CancellationToken token)
    {
        var buf = new byte[4096];
        try
        {
            while (!token.IsCancellationRequested)
            {
                int n = await s.ReadAsync(buf, 0, buf.Length, token);
                if (n == 0)
                {
                    Log("Connection closed by the Receiver");
                    break;
                }
                foreach (byte[] frame in asm.Feed(buf, n, w => Log(w)))
                    HandleReply(frame);
            }
        }
        catch (OperationCanceledException) { }
        catch (IOException) { }
        catch (ObjectDisposedException) { }

        byte[]? rest = asm.Finish(w => Log(w));
        if (rest != null && !token.IsCancellationRequested) HandleReply(rest);
    }

    // Framing = None: a burst of reply data with no pause is one reply
    private void PollReplyGap()
    {
        byte[]? data = assembler.PollGap(settings.MessageGapMs);
        if (data != null) HandleReply(data);
    }

    // ================= replies from the Receiver =================

    private void HandleReply(byte[] content)
    {
        byte[] payload = FrameBuilder.Unwrap(content, settings.Framing, settings.Checksum, out bool? checksumOk);
        string text = Encoding.UTF8.GetString(payload);
        string trimmed = text.Trim();

        if (checksumOk == false)
        {
            Log("Reply with BAD CHECKSUM ignored");
            return;
        }

        bool isAck = settings.AckText.Length > 0 && trimmed.Equals(settings.AckText, StringComparison.OrdinalIgnoreCase);
        bool isNak = settings.NakText.Length > 0 && trimmed.Equals(settings.NakText, StringComparison.OrdinalIgnoreCase);

        if ((isAck || isNak) && ackWaiter != null)
        {
            ackWaiter.TrySetResult(isAck);
            return;
        }
        Log("Reply from Receiver: " + Util.OneLine(text));
    }

    // ================= sending =================

    // Sends one message. With "Wait for ACK" on, it waits for ACK and sends again if needed.
    private async Task<bool> SendMessageAsync(byte[] payload)
    {
        await sendGate.WaitAsync();
        try
        {
            if (stream == null)
            {
                Log("Not connected - message not sent");
                return false;
            }

            byte[] frame;
            try
            {
                frame = FrameBuilder.Wrap(payload, settings.Framing, settings.Checksum, settings.FixedLength);
            }
            catch (Exception ex)
            {
                Log($"Cannot build the message: {ex.Message}");
                return false;
            }

            int attempts = settings.WaitAck ? 1 + settings.Retries : 1;
            for (int attempt = 1; attempt <= attempts; attempt++)
            {
                TaskCompletionSource<bool>? waiter = null;
                if (settings.WaitAck)
                {
                    waiter = new TaskCompletionSource<bool>(TaskCreationOptions.RunContinuationsAsynchronously);
                    ackWaiter = waiter;
                }

                if (!await WriteFrameAsync(frame))
                {
                    ackWaiter = null;
                    return false;
                }
                if (waiter == null) return true;

                Task finished = await Task.WhenAny(waiter.Task, Task.Delay(settings.AckTimeoutMs));
                ackWaiter = null;

                if (finished == waiter.Task)
                {
                    if (waiter.Task.Result) return true;
                    Log("NAK received from the Receiver");
                }
                else
                {
                    Log($"No ACK within {settings.AckTimeoutMs} ms");
                }
                if (attempt < attempts) Log($"Sending again ({attempt}/{attempts - 1}) ...");
            }

            Log("Giving up: the message was not acknowledged");
            return false;
        }
        finally
        {
            sendGate.Release();
        }
    }

    private async Task<bool> WriteFrameAsync(byte[] frame)
    {
        var s = stream;
        if (s == null) return false;
        try
        {
            await s.WriteAsync(frame, 0, frame.Length);
            return true;
        }
        catch (Exception ex)
        {
            Log($"Send failed: {ex.Message}");
            DropConnection();   // the connection loop will reconnect
            return false;
        }
    }

    // ---- 1. send-folder cycle (the old "Entire_Cycle") ----

    private async Task CycleAsync()
    {
        if (cycleBusy || stream == null) return;
        cycleBusy = true;
        try
        {
            string? file = FindEarliestFile();
            if (file != null) await SendFileAsync(file);
        }
        catch (Exception ex)
        {
            Log($"Cycle error: {ex.Message}");
        }
        finally
        {
            cycleBusy = false;
        }
    }

    private string? FindEarliestFile()
    {
        string dir = settings.SendFolder;
        if (string.IsNullOrWhiteSpace(dir) || !Directory.Exists(dir)) return null;

        FileInfo? best = null;
        foreach (FileInfo fi in new DirectoryInfo(dir).EnumerateFiles("*" + settings.SendFileFormat))
        {
            // skip files that are still being written / copied
            if (DateTime.UtcNow - fi.LastWriteTimeUtc < TimeSpan.FromMilliseconds(500)) continue;
            if (best == null || fi.LastWriteTimeUtc < best.LastWriteTimeUtc) best = fi;
        }
        return best?.FullName;
    }

    private async Task SendFileAsync(string path)
    {
        byte[] data;
        try
        {
            data = await Task.Run(() => File.ReadAllBytes(path));
        }
        catch (IOException)
        {
            return;   // file is busy, try again in the next cycle
        }

        string text = Encoding.UTF8.GetString(data);
        txtSendingContent.Text = text.Length > 5000 ? text.Substring(0, 5000) + " ..." : text;
        Log($"{Path.GetFileName(path)} started");

        bool ok = data.Length == 0 || await SendMessageAsync(data);
        if (!ok)
        {
            Log($"{Path.GetFileName(path)} NOT sent - will try again");
            return;
        }

        Log("Fuzion Machine Sent To AOI: " + Util.OneLine(text));
        MoveToSent(path);
        Log($"{Path.GetFileName(path)} finished");
    }

    private void MoveToSent(string path)
    {
        string sentDir = Path.Combine(Path.GetDirectoryName(path)!, "Sent");
        Directory.CreateDirectory(sentDir);

        string name = Path.GetFileName(path);
        string dest = Path.Combine(sentDir, name);
        if (File.Exists(dest))
            dest = Path.Combine(sentDir, Path.GetFileNameWithoutExtension(name) + "_" + DateTime.Now.ToString("yyyyMMdd_HHmmss_fff") + Path.GetExtension(name));
        File.Move(path, dest);
    }

    // ---- 2. manual send ----

    private async Task SendManualAsync()
    {
        string text = txtManual.Text;
        if (text.Length == 0) return;
        if (stream == null)
        {
            Log("Not connected - message not sent");
            return;
        }

        btnManual.Enabled = false;
        try
        {
            if (await SendMessageAsync(Encoding.UTF8.GetBytes(text)))
            {
                txtSendingContent.Text = text;
                Log("Sent: " + Util.OneLine(text));
                txtManual.Clear();
            }
        }
        finally
        {
            btnManual.Enabled = true;
        }
    }

    // ---- 2b. load a file (text / XML / CSV) and send its content ----

    private async Task LoadFileAndSendAsync()
    {
        using var dlg = new OpenFileDialog
        {
            Title = "Load file to send",
            Filter = "Text / XML / CSV files (*.txt;*.xml;*.csv)|*.txt;*.xml;*.csv|Text file (*.txt)|*.txt|XML file (*.xml)|*.xml|CSV file (*.csv)|*.csv|All files (*.*)|*.*",
            CheckFileExists = true
        };
        if (dlg.ShowDialog(this) != DialogResult.OK) return;

        if (stream == null)
        {
            Log("Not connected - file not sent");
            return;
        }

        btnLoadFile.Enabled = false;
        btnManual.Enabled = false;
        try
        {
            string path = dlg.FileName;
            byte[] data;
            try
            {
                data = await Task.Run(() => File.ReadAllBytes(path));
            }
            catch (Exception ex)
            {
                Log($"Cannot read {Path.GetFileName(path)}: {ex.Message}");
                return;
            }

            if (data.Length == 0)
            {
                Log($"{Path.GetFileName(path)} is empty - nothing sent");
                return;
            }

            string text = Encoding.UTF8.GetString(data);
            txtSendingContent.Text = text.Length > 5000 ? text.Substring(0, 5000) + " ..." : text;
            Log($"{Path.GetFileName(path)} loaded ({data.Length} bytes) - sending");

            if (await SendMessageAsync(data))
                Log($"File sent: {Path.GetFileName(path)}  [{Util.OneLine(text, 120)}]");
            else
                Log($"{Path.GetFileName(path)} NOT sent");
        }
        finally
        {
            btnLoadFile.Enabled = true;
            btnManual.Enabled = true;
        }
    }

    // ---- 3. auto-send ----

    private void AutoSendChanged()
    {
        if (chkAutoSend.Checked)
        {
            if (settings.AutoSendText.Length == 0)
            {
                MessageBox.Show(this, "Type the Auto-send text first (Settings > 5. Auto-send).", "Tip", MessageBoxButtons.OK, MessageBoxIcon.Information);
                chkAutoSend.Checked = false;
                return;
            }
            autoSendTimer.Interval = Math.Max(50, settings.AutoSendIntervalMs);
            autoSendTimer.Start();
            Log($"Auto-send ON every {settings.AutoSendIntervalMs} ms");
        }
        else
        {
            autoSendTimer.Stop();
            Log("Auto-send OFF");
        }
    }

    private async Task AutoSendTickAsync()
    {
        if (autoBusy || stream == null) return;
        autoBusy = true;
        try
        {
            string text = settings.AutoSendText;
            if (text.Length == 0) return;
            if (await SendMessageAsync(Encoding.UTF8.GetBytes(text)))
            {
                txtSendingContent.Text = text;
                Log("Auto-send: " + Util.OneLine(text));
            }
        }
        finally
        {
            autoBusy = false;
        }
    }

    // ================= status / log =================

    private void SetStatus(string text, Color color)
    {
        if (IsDisposed) return;
        if (InvokeRequired) { BeginInvoke(() => SetStatus(text, color)); return; }
        lblStatus.ForeColor = color;
        lblStatus.Text = text;
    }

    private void Log(string text)
    {
        if (IsDisposed) return;
        if (InvokeRequired) { BeginInvoke(() => Log(text)); return; }
        txtLog.AddLine(text);
    }

    // ================= closing (password, like the old app) =================

    protected override void OnFormClosing(FormClosingEventArgs e)
    {
        if (e.CloseReason == CloseReason.UserClosing)
        {
            if (!PasswordGate.Ask(this, cfg, "Close"))
            {
                e.Cancel = true;
                return;
            }
        }
        cycleTimer.Stop();
        replyTimer.Stop();
        autoSendTimer.Stop();
        StopConnection();
        base.OnFormClosing(e);
    }
}
